package com.projetee.sallesmangement.entity;

public enum Role {
    ADMIN,
    VENDEUR,
    ANALYSTE,
    ACHETEUR,
    INVESTISSEUR
}
