package com.projetee.sallesmangement.entity;

public enum AlertPriority {
    LOW,
    MEDIUM,
    HIGH
}