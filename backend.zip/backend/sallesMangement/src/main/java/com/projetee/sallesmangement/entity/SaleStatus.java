package com.projetee.sallesmangement.entity;

public enum SaleStatus {
    CREATED,
    CONFIRMED,
    CANCELLED
}