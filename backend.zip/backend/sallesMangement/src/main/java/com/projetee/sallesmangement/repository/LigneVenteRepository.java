package com.projetee.sallesmangement.repository;

import com.projetee.sallesmangement.entity.LigneVente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LigneVenteRepository extends JpaRepository<LigneVente, Long> {
}
