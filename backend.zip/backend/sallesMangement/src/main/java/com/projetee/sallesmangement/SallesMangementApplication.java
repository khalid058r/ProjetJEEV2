package com.projetee.sallesmangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SallesMangementApplication {

    public static void main(String[] args) {
        SpringApplication.run(SallesMangementApplication.class, args);
    }

}
